/*
 * File:   adc.c
 * Author: Dell
 *
 * Created on 14 October, 2026, 12:36 PM
 */


#include <xc.h>

void main(void) {
    return;
}
